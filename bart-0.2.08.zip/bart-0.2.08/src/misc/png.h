
extern int png_write_rgb24(const char* name, unsigned int w, unsigned int h, const unsigned char* buf);

