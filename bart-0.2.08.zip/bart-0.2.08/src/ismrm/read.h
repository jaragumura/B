
#include "misc/mri.h"

#ifdef __cplusplus
extern "C" {
#endif

extern int ismrm_read(const char* datafile, long dims[DIMS], _Complex float* buf);

#ifdef __cplusplus
}
#endif

