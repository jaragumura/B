#!/bin/bash
doxygen doxyconfig
